package org.example.repository;

import org.example.domain.Dish;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface DishRepository extends JpaRepository<Dish, Integer> {
    Page<Dish> findAllByCategoryId(int id, Pageable pageable);

    @EntityGraph(attributePaths = {"ingredient", "image"})
    Dish findById(int id);

    @EntityGraph(attributePaths = {"image", "ingredient"})
    List<Dish> findByCategoryId(int id);


@Query("select d from Dish d join d.category c where c.id in :ids group by d.id" +
            " having count(d.id) = :idCount")
    List<Dish> findDishsByCategoryIds(@Param("ids") List<Integer> ids, @Param("idCount") long idCount);
}
