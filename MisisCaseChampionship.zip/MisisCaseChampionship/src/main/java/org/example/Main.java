package org.example;

import org.example.repository.*;
import org.example.service.CategoryService;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;

@SpringBootApplication
public class Main {
    public static void main(String[] args) {

        ConfigurableApplicationContext run = SpringApplication.run(Main.class, args);

        System.out.println(run.getBean(CategoryService.class).findAll());
    }
}