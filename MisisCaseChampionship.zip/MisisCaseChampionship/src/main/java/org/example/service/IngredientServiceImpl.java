package org.example.service;

public class IngredientServiceImpl {
}
