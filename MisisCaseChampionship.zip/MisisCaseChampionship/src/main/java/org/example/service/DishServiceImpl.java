package org.example.service;

import lombok.RequiredArgsConstructor;
import org.example.domain.Dish;
import org.example.repository.DishRepository;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

@RequiredArgsConstructor
@Service
public class DishServiceImpl implements DishService{

    private final DishRepository dishRepository;

    @Override
    public List<Dish> findByCategoryId(int id) {
        return dishRepository.findByCategoryId(id);
    }

    @Override
    public List<Dish> findTenByCategoryId(int id) {
        return dishRepository.findAllByCategoryId(id, PageRequest.of(0, 10)).toList();
    }

    @Override
    public Dish findById(int id) {
        return dishRepository.findById(id);
    }

    @Transactional
    @Override
    public Dish insert(Dish dish) {
        return dishRepository.save(dish);
    }

    @Override
    public List<Dish> findByCategoryIds(List<Integer> ids) {

        return dishRepository.findDishsByCategoryIds(ids, ids.size());
    }
}
