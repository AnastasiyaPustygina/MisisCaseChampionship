package org.example.service;

import lombok.RequiredArgsConstructor;
import org.example.domain.Product;
import org.example.repository.ProductRepository;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class ProductServiceImpl implements ProductService{

    private final ProductRepository productRepository;

    @Override
    public Product findByIngredientId(int id) {
        return productRepository.findByIngredientId(id);
    }
}
