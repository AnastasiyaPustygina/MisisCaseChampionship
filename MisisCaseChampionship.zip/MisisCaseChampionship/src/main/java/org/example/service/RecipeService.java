package org.example.service;

import org.example.domain.Recipe;

public interface RecipeService {
    Recipe findByDishId(int id);
    void removeRecipeFromFavouritesByPersonIdAndRecipeId(int personId, int recipeId);
    void addRecipeToFavouritesByPersonIdAndRecipeId(int personId, int recipeId);
}
