package org.example.service;

import org.example.domain.Dish;

import java.util.List;
import java.util.Optional;

public interface DishService {
    List<Dish> findByCategoryId(int id);
    List<Dish> findTenByCategoryId(int id);
    Dish findById(int id);
    Dish insert(Dish dish);
    //поиск блюда, попадающего во все указанные категории
    List<Dish> findByCategoryIds(List<Integer> ids);
}
