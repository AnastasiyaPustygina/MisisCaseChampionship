package org.example.service;

import lombok.RequiredArgsConstructor;
import org.example.domain.Recipe;
import org.example.repository.RecipeRepository;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class RecipeServiceImpl implements RecipeService{

    private final RecipeRepository recipeRepository;

    @Override
    public Recipe findByDishId(int id) {
        return recipeRepository.findByDishId(id);
    }
    @Override
    public void removeRecipeFromFavouritesByPersonIdAndRecipeId(int personId, int recipeId) {
        recipeRepository.removeRecipeFromFavouritesByPersonIdAndRecipeId(personId, recipeId);
    }

    @Override
    public void addRecipeToFavouritesByPersonIdAndRecipeId(int personId, int recipeId) {
        recipeRepository.addRecipeToFavouritesByPersonIdAndRecipeId(personId, recipeId);
    }
}
