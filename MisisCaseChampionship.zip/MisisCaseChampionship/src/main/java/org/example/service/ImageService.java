package org.example.service;

import org.example.domain.Image;

public interface ImageService {

}
