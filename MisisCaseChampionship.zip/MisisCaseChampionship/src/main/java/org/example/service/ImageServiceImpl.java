package org.example.service;

import lombok.RequiredArgsConstructor;
import org.example.domain.Image;
import org.example.repository.ImageRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;


public class ImageServiceImpl {

}
