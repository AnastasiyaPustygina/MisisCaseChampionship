package org.example.service;

import org.example.domain.Category;

import java.util.List;

public interface CategoryService {

    List<Category> findAll();

    Category insert(Category category);

}
